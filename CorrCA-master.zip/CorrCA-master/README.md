# CorrCA
Correlated Components Analysis (CorrCA) written in Python based on the [original Matlab code](https://www.parralab.org/corrca/) from Parra's Lab.
